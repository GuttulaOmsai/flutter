# Fluttter_SinglePageUI

All the single screen files to make an app

1. Login_Simple
2. SignUp_Simple
3. Notes_Simple
4. Login_Instagram_Clone
