package com.example.chess_board_game;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
