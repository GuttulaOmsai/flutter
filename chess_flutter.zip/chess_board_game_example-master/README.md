# Chess Game

A Chess Game using Flutter.

## Getting Started

This project covers how to make chess game using flutter. Also it shows how to build more advance functionalities.

Watch below [Youtube](https://www.youtube.com/watch?v=R-3H6sbu6nw) video for the code walkthrough,

[![Chess Board Game Example](https://img.youtube.com/vi/R-3H6sbu6nw/0.jpg)](https://www.youtube.com/watch?v=R-3H6sbu6nw)
