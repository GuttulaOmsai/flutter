package com.example.imge

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
