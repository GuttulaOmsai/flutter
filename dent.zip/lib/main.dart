import 'package:flutter/material.dart';

void main() {
  runApp(DentalApp());
}

class DentalApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Dental App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => LandingPage(),
        '/mainFeatures': (context) => MainFeaturesPage(),
        '/about': (context) => AboutPage(),
        '/getStarted': (context) => GetStartedPage(),
      },
    );
  }
}

class LandingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Welcome to Dental App'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              'android/assets/images/download.jpeg', // Add your logo image asset
              width: 150,
              height: 150,
            ),
            SizedBox(height: 20),
            Text(
              'Your Dental Health Companion',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                // Navigate to the Get Started page
                Navigator.pushNamed(context, '/getStarted');
              },
              child: Text('Get Started'),
            ),
            SizedBox(height: 10),
            TextButton(
              onPressed: () {
                // Navigate to the about page
                Navigator.pushNamed(context, '/about');
              },
              child: Text('About'),
            ),
          ],
        ),
      ),
    );
  }
}

class MainFeaturesPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Main Features'),
      ),
      body: Center(
        child: Text('This is the main features page.'),
      ),
    );
  }
}

class AboutPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('About Dental App'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Text(
            'The Dental App is designed to provide users with convenient access to dental health information and services. Our goal is to promote oral health and facilitate communication between patients and dental professionals.',
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}

class GetStartedPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Get Started'),
      ),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Enter your information:',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10),
            TextField(
              decoration: InputDecoration(
                labelText: 'Name',
              ),
            ),
            TextField(
              decoration: InputDecoration(
                labelText: 'Email',
              ),
            ),
            TextField(
              decoration: InputDecoration(
                labelText: 'Phone',
              ),
            ),
            SizedBox(height: 20),
            Text(
              'Images for dental health:',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10),
            Image.asset(
              'android/assets/images/download.jpeg',
              width: double.infinity,
            ),
            SizedBox(height: 10),
            Image.asset(
              'android/assets/images/download.jpeg',
              width: double.infinity,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Implement functionality for button press
              },
              child: Text('Submit'),
            ),
          ],
        ),
      ),
    );
  }
}
