class Category {
  int categoryId;
  String categoryName;
  String categoryImage;

  Category({
    required this.categoryId,
    required this.categoryName,
    required this.categoryImage});
}