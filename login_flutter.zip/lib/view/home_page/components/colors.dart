import 'dart:ui';

var buttonColor = Color(0xFFFF9505);
var registerColor = Color(0xFFffdfb4);
var lightColor = Color(0xFFFFC971);
var freeDelivery = Color(0xFF025939);
var textColor = Color(0xFFf2ac29);
var texthint = Color(0xFF666666);
var passiveFavorite = Color(0xFFD9886A);