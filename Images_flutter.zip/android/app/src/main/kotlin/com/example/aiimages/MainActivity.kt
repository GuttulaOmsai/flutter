package com.example.aiimages

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
